"use client";

import { useEffect, useState } from "react";
import Sidebar from "../components/sidebar";
import Header from "../components/headers";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencil, faTrash, faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { jsPDF } from 'jspdf';
import { autoTable } from 'jspdf-autotable';

type MenuItem = {
  idMenu: any;
  namaMenu: string;
  harga: number;
  stok: number;
};

interface MenuResponse {
  success: boolean;
  data?: MenuItem[];
  message?: string;
}

interface MejaResponse {
  success: boolean;
  idMeja: Number;
  idPelanggan: Number;
  status: string
}

type OrderResponse = {
  idPesanan: number;
  namaMenu: string;
  jumlah: string;
  idPelanggan: number;
  idUser: number;
  createdAt: string;
  idMeja: number;
  status: string;
};

type ParsedOrder = {
  namaMenu: string;
  jumlah: string;
  idPesanan: number;
  idPelanggan: number;
  idMeja: number;
  status: string;
};

export default function Home() {
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [menus, setMenus] = useState<MenuItem[]>([]);
  const [orderItems, setOrderItems] = useState<Record<string, number>>({});
  const [currentPage, setCurrentPage] = useState(1);
  const [menuDetails, setMenuDetails] = useState<MenuItem[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [table, setTable] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<number | null>(null);
  const [selectedTable, setSelectedTable] = useState<number | null>(null);
  const itemsPerPage = 10;
  const [searchQuery, setSearchQuery] = useState('');
  const [notification, setNotification] = useState<{
    type: 'success' | 'error',
    message: string
  } | null>(null);
  const [totalPesanan, setTotalPesanan] = useState(0);
  const [uangBayar, setUangBayar] = useState(0);
  const [kembalian, setKembalian] = useState(0);
  const [orderList, setOrderList] = useState<ParsedOrder[]>([]);


  useEffect(() => {
    const total = Object.entries(orderItems).reduce((acc, [idMenu, qty]) => {
      const menu = menus.find(m => m.idMenu === Number(idMenu));
      if (menu && qty > 0) {
        return acc + (menu.harga * qty);
      }
      return acc;
    }, 0);
    setTotalPesanan(total);
    setKembalian(uangBayar - total);
  }, [orderItems, uangBayar, menus]);

  useEffect(() => {
    async function fetchOrder() {
      const res = await fetch("/api/order");
      const data = await res.json();
  
      const parsedOrders: ParsedOrder[] = [];
  
      (data.data as OrderResponse[]).forEach((order: OrderResponse) => {

        const menuList = order.namaMenu.split(", ");
        const jumlahList = order.jumlah.split(", ");
      
        const combinedMenu = menuList.map((menu, index) => `${menu}`).join(", ");
        parsedOrders.push({
          namaMenu: combinedMenu,
          jumlah: order.jumlah,
          idPesanan: order.idPesanan,
          idPelanggan: order.idPelanggan,
          idMeja: order.idMeja,
          status: order.status
        });
      });
      
      setOrderList(parsedOrders);
    }
  
    fetchOrder();
  }, []);

    
  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3000);
  };

  useEffect(() => {
    const fetchUsers = async () => {
      const response = await fetch('/api/customer');
      const data = await response.json();
      console.log(data)
      if (data) {
        setUsers(data.data);
      }
    };

    fetchUsers();
  }, []);

  useEffect(() => {
    if (showOrderModal) {
      fetch('/api/menu')
        .then(res => res.json())
        .then((data: MenuResponse) => {
            console.log(data)
          if (data.success && data.data) {
            setMenus(data.data);
            const initialOrder: Record<string, number> = {};
            data.data.forEach(item => {
              initialOrder[item.idMenu] = 0;
            });
            setOrderItems(initialOrder);
          }
        });
    }
  }, [showOrderModal]);

  useEffect(() => {
    if (showOrderModal) {
      fetch('/api/meja')
        .then(res => res.json())
        .then((data: any[]) => {
          if (Array.isArray(data)) {
            // Filter meja yang available
            const availableMeja = data.filter(meja => meja.status === 'available');
            setTable(availableMeja);
          }
        });
    }
  }, [showOrderModal]);
  

  const fetchMenuDetails = async () => {
    try {
      const res = await fetch('/api/menu');
      const data: MenuResponse = await res.json();
      if (data.success && data.data) {
        setMenuDetails(data.data);
      }
    } catch (error) {
      console.error("Failed to fetch menu data", error);
    }
  };

  const updateQuantity = (idMenu: string, delta: number) => {
    console.log(idMenu)
    setOrderItems(prev => ({
      ...prev,
      [idMenu]: Math.max(0, (prev[idMenu] || 0) + delta)
    }));
  };

  const submitOrder = async () => {
    if (!selectedUser || !selectedTable) {
      alert("Silakan pilih pengguna dan meja terlebih dahulu.");
      return;
    }
  
    const selectedItems = Object.entries(orderItems)
      .filter(([, qty]) => qty > 0)
      .map(([idMenu, qty]) => {
        return {
          idMenu: Number(idMenu),
          jumlah: Number(qty)
        };
      });
  
    if (selectedItems.length === 0) {
      alert("Tidak ada item yang dipilih.");
      return;
    }
  
    // Gabungkan idMenu dan jumlah jadi string
    const idMenuString = selectedItems.map(item => item.idMenu).join(",");
    const jumlahString = selectedItems.map(item => item.jumlah).join(",");
  
    try {
      const response = await fetch("/api/order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          idPelanggan: selectedUser,
          idUser: selectedUser,
          idMeja: selectedTable,
          idMenu: idMenuString,
          jumlah: jumlahString,
          total: totalPesanan
        })
      });
  
      const result = await response.json();
  
      if (result.success) {
        alert("Pesanan berhasil dikirim!");
        setShowOrderModal(false);
        setOrderItems({});
        setSelectedUser(null);
        setSelectedTable(null);
        setUangBayar(0);
        setKembalian(0)
      } else {
        alert(`Gagal mengirim pesanan: ${result.message}`);
      }
    } catch (error) {
      alert("Terjadi kesalahan saat mengirim pesanan.");
      console.error(error);
    }
  };


  useEffect(() => {
    fetchMenuDetails();
  }, []);

  const handleDelete = async (idPesanan: number) => {
    const response = await fetch("/api/order", {
      method: "DELETE",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ idPesanan })
    })
  }

  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = menuDetails.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(menuDetails.length / itemsPerPage);

  const handlePagination = (direction: 'next' | 'prev') => {
    setCurrentPage(prev => direction === 'next' ? Math.min(prev + 1, totalPages) : Math.max(prev - 1, 1));
  };

  const generatePDFReport = () => {
    const doc = new jsPDF();
    const tableColumn = ["ID Pesanan", "ID Pelanggan", "Menu", "ID Meja", "Status"];
    const tableRows: any[] = [];
  
    let totalPesanan = 0;
  
    orderList.forEach((item: ParsedOrder) => {
      const row = [
        item.idPesanan,
        item.idPelanggan,
        item.namaMenu,
        item.idMeja,
        item.status,
      ];
      tableRows.push(row);
  
      totalPesanan += 1; // menghitung total order
    });
  
    doc.setFontSize(18);
    doc.text("Laporan Pesanan", 14, 15);
    doc.setFontSize(11);
    doc.text(`Tanggal Cetak: ${new Date().toLocaleDateString()}`, 14, 23);
  
    // Tabel
    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 30,
      theme: "striped",
      styles: {
        font: "helvetica",
        fontSize: 10,
      },
      headStyles: {
        fillColor: [111, 130, 106], // warna header (sesuai theme mu)
      },
    });
  
    const finalY = (doc as any).lastAutoTable.finalY || 40;
  
    // Summary
    doc.text(`Total Pesanan: ${totalPesanan}`, 14, finalY + 10);
  
    // Footer
    doc.text(`Kasir: ${localStorage.getItem('email')}`, 14, finalY + 30);
  
    doc.save(`laporan-pesanan-${new Date().toISOString().slice(0,10)}.pdf`);
  };
  

  return (
    <div className="flex md:flex-row w-full bg-[#F0F1C5]/30 h-screen font-mono overflow-hidden">
      <Sidebar />
      <div className="flex flex-col overflow-auto w-full h-full">
        <Header />
        
        {/* Notification */}
        {notification && (
          <div className={`fixed top-0 right-0 mr-4 mt-4 z-[60] px-4 py-2 rounded-md shadow-lg text-sm transition-all duration-300
            ${notification.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
            {notification.message}
          </div>
        )}

        {/* Main Content */}
        <div className="bg-[#6F826A] rounded-md shadow-sm ml-1 mr-2 mt-2 p-4">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-2xl font-bold text-white">Menu Order</h1>
            <div className="flex gap-2">
              <button 
                className="px-4 py-2 bg-white text-[#6F826A] rounded-md hover:bg-gray-100"
                onClick={() => setShowOrderModal(true)}
              >
                New Order
              </button>
              <button 
                onClick={generatePDFReport}
                className="px-4 py-2 bg-white text-[#6F826A] rounded-md hover:bg-gray-100"
              >
                Export PDF
              </button>

            </div>
          </div>

          {/* Search Bar */}
          <div className="mb-4 flex items-center bg-white rounded-md p-2">
            <FontAwesomeIcon icon={faMagnifyingGlass} className="text-[#6F826A] mx-2" />
            <input 
              type="text" 
              placeholder="Cari order..." 
              className="w-full outline-none bg-transparent"
            />
          </div>
          <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID Pesanan</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID Pelanggan</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Menu & Jumlah Pesanan</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID Meja</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">STATUS</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
              {orderList.map((item: ParsedOrder, index: number) => (
                <tr key={index}>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-500">{item.idPesanan}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-500">{item.idPelanggan}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-500">{item.namaMenu}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-500">{item.idMeja}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-500">{item.status}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-500 text-center">
                    <button className="text-red-500 hover:text-red-700" onClick={() => handleDelete(item.idPelanggan)}>
                      <FontAwesomeIcon icon={faTrash} />
                    </button>
                  </td>
                </tr>
              ))}

              </tbody>
            </table> 
         </div> 

          {/* Pagination */}
          <div className="mt-4 flex justify-between items-center">
            <span className="text-sm text-gray-200">
              Halaman {currentPage} dari {totalPages}
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => handlePagination('prev')}
                disabled={currentPage === 1}
                className="px-4 py-2 bg-white text-[#6F826A] rounded-md disabled:opacity-50"
              >
                Previous
              </button>
              <button
                onClick={() => handlePagination('next')}
                disabled={currentPage === totalPages}
                className="px-4 py-2 bg-white text-[#6F826A] rounded-md disabled:opacity-50"
              >
                Next
              </button>
            </div>
          </div>
        </div>

        {/* Order Modal */}
        {showOrderModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto text-[#6F826A]">
              <h2 className="text-xl font-bold mb-4">Pesanan Baru</h2>

              {/* User Selection */}
              <div className="mb-4">
                <label htmlFor="userSelect" className="block mb-2">Pilih Pelanggan</label>
                <select id="userSelect" className="w-full p-2 border rounded text-black bg-white" onChange={(e) => setSelectedUser(Number(e.target.value))} value={selectedUser || ''}>
                  <option value="">-- Pilih Pengguna --</option>
                  {users.map((user, index) => (
                    <option key={user.idPelanggan || index} value={user.idPelanggan}>
                      {user.fullName}
                    </option>
                  ))}
                </select>

                <label htmlFor="mejaSelect" className="block mt-2 mb-2">Pilih Meja</label>
                <select id="mejaSelect" className="w-full p-2 border rounded text-black bg-white" onChange={(e) => setSelectedTable(Number(e.target.value))} value={selectedTable || ''}>
                  <option value="">-- Pilih Meja --</option>
                  {table.map((meja, index) => (
                    <option key={meja.idMeja || index} value={meja.idMeja}>
                      Meja {meja.idMeja}
                    </option>
                  ))}
                </select>
              </div>

              {/* Search Menu */}
              <div className="mb-4">
                <input 
                  type="text" 
                  placeholder="Cari menu..." 
                  className="w-full p-2 border rounded text-black mb-2"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {/* Menu Table */}
              <div className="w-full max-h-[300px] overflow-y-auto mb-4 rounded"> {/* batasi tinggi 4 item, tapi tetap bisa scroll */}
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="pb-2">Order</th>
                      <th className="pb-2">Harga</th>
                      <th className="pb-2 text-center">Jumlah</th>
                    </tr>
                  </thead>
                  <tbody>
                    {menus
                      .filter((item) => item.namaMenu.toLowerCase().includes(searchQuery.toLowerCase()))
                      .map((item) => (
                        <tr key={item.idMenu} className="border-b">
                          <td className="py-3">{item.namaMenu}</td>
                          <td className="py-3">Rp {item.harga.toLocaleString()}</td>
                          <td className="py-3 flex items-center justify-center gap-2">
                            <button
                              onClick={() => updateQuantity(item.idMenu, -1)}
                              disabled={orderItems[item.idMenu] <= 0}
                              className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
                            >
                              -
                            </button>

                            <span className="w-8 text-center">{orderItems[item.idMenu] || 0}</span>

                            <button
                              onClick={() => updateQuantity(item.idMenu, 1)}
                              className="px-3 py-1 bg-gray-200 rounded"
                            >
                              +
                            </button>
                          </td>
                        </tr>
                    ))}
                  </tbody>
                </table>
              </div>


              {/* Action Button */}
              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setShowOrderModal(false)}
                  className="px-4 py-2 bg-gray-300 rounded-md"
                >
                  Batal
                </button>
                <button
                  onClick={submitOrder}
                  className="px-4 py-2 bg-[#6F826A] text-white rounded-md"
                >
                  Proses Pesanan
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}