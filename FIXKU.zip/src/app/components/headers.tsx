'use client'

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faCircleUser } from "@fortawesome/free-solid-svg-icons"
import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"

export default function Header() {
  const [username, setUsername] = useState<string | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const router = useRouter()

  useEffect(() => {
    const savedUsername = localStorage.getItem("username")
    setUsername(savedUsername)

    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setMenuOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("username")
    localStorage.removeItem("token")
    router.push("/")
  }

  return (
    <div className="font-mono relative flex bg-[#6F826A] h-12 rounded-sm ml-1 mr-2 mt-2 items-center justify-end">
      <FontAwesomeIcon icon={faCircleUser} className="w-6 h-6 text-white" />
      <div className="relative" ref={dropdownRef}>
        <button onClick={() => setMenuOpen(!menuOpen)} className="cursor-pointer text-white px-4 py-2 hover:text-gray-600">
          {username || 'Guest'}
        </button>

        {menuOpen && (
          <div className="absolute right-0 mt-2 bg-white border border-gray-200 rounded shadow-md w-32 z-50">
            <button onClick={handleLogout} className="cursor-pointer block w-full text-left px-4 py-2 text-sm text-gray-400 hover:text-gray-600 hover:bg-gray-100">Logout</button>
          </div>
        )}
      </div>
    </div>
  )
}
