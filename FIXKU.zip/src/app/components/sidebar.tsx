import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBox, faReceipt, faUserGroup, faCashRegister, faList, faUser, faBars, faChair } from "@fortawesome/free-solid-svg-icons";
import { useState, useEffect } from "react";
import Link from 'next/link';

export default function Sidebar() {
  const [open, setOpen] = useState(false);
  const [role, setRole] = useState<string | null>(null);

  useEffect(() => {
    // Get the role from localStorage
    const userRole = localStorage.getItem("role");
    setRole(userRole);
  }, []);

  return (
    <>
      <button onClick={() => setOpen(!open)} className="md:hidden fixed top-5 left-5 z-50 p-2 bg-[#]">
        <FontAwesomeIcon icon={faBars} className="w-5 h-5 text-[#6F826A]" />
      </button>
      <div
        className={`${open ? "translate-x-0" : "-translate-x-full"} rounded-sm md:translate-x-0 fixed md:static top-0 left-0 z-40 h-[calc(100vh-1rem)] w-64 md:w-2/12 mt-2 mb-2 mx-2 bg-[#6F826A] shadow md:shadow-none transition-transform duration-300 ease-in-out flex flex-col items-center font-medium`}>
        <p className="mt-6 mb-8 text-xl font-semibold text-[#F0F1C5]">MieAyam</p>
        <ul className="w-full">
          {/* Always visible */}
          <li className="flex items-center px-5 py-2 text-sm text-white rounded-sm duration-200 ease-in-out hover:text-[#938de9] hover:bg-[#e7e7ff] whitespace-nowrap">
            <Link href="/dashboard" className="flex items-center space-x-2 w-full p-2">
              <FontAwesomeIcon icon={faList} className="w-6 h-4" />
              <span>Dashboard</span>
            </Link>
          </li>

          {/* Rendered for Admin and Waiter */}
          {role === 'admin' ? (
            <>
              <li className="flex items-center px-5 py-2 text-sm text-white rounded-sm duration-200 ease-in-out hover:text-[#938de9] hover:bg-[#e7e7ff] whitespace-nowrap">
                <Link href="/meja" className="flex items-center space-x-2 w-full p-2">
                  <FontAwesomeIcon icon={faChair} className="w-6 h-4" />
                  <span>Meja</span>
                </Link>
              </li>

              <li className="flex items-center px-5 py-2 text-sm text-white rounded-sm duration-200 ease-in-out hover:text-[#938de9] hover:bg-[#e7e7ff] whitespace-nowrap">
                <Link href="/menu" className="flex items-center space-x-2 w-full p-2">
                  <FontAwesomeIcon icon={faBox} className="w-6 h-4" />
                  <span>Menu</span>
                </Link>
              </li>
            </>
          ) : null}

          {/* Rendered only for Admin */}
          {role === 'waiter' ? (
            <>
              <li className="flex items-center px-5 py-2 text-sm text-white rounded-sm duration-200 ease-in-out hover:text-[#938de9] hover:bg-[#e7e7ff] whitespace-nowrap">
                <Link href="/menu" className="flex items-center space-x-2 w-full p-2">
                  <FontAwesomeIcon icon={faBox} className="w-6 h-4" />
                  <span>Menu</span>
                </Link>
              </li>

              <li className="flex items-center px-5 py-2 text-sm text-white rounded-sm duration-200 ease-in-out hover:text-[#938de9] hover:bg-[#e7e7ff] whitespace-nowrap">
                <Link href="/order" className="flex items-center space-x-2 w-full p-2">
                  <FontAwesomeIcon icon={faReceipt} className="w-6 h-4" />
                  <span>Order</span>
                </Link>
              </li>
            </>
          ) : null}

          {role === 'admin' ? (
            <>
              <li className="flex items-center px-5 py-2 text-sm text-white rounded-sm duration-200 ease-in-out hover:text-[#938de9] hover:bg-[#e7e7ff] whitespace-nowrap">
                <Link href="/users" className="flex items-center space-x-2 w-full p-2">
                  <FontAwesomeIcon icon={faUser} className="w-6 h-4" />
                  <span>User</span>
                </Link>
              </li>
            </>
          ) : null}

          {/* Rendered for Kasir */}
          {role === 'kasir' ? (
            <li className="flex items-center px-5 py-2 text-sm text-white rounded-sm duration-200 ease-in-out hover:text-[#938de9] hover:bg-[#e7e7ff] whitespace-nowrap">
              <Link href="/transaction" className="flex items-center space-x-2 w-full p-2">
                <FontAwesomeIcon icon={faCashRegister} className="w-6 h-4" />
                <span>Transaksi</span>
              </Link>
            </li>
          ) : null}
        </ul>
      </div>

      {open && (
        <div
          onClick={() => setOpen(false)}
          className="fixed inset-0 bg-black/30 z-30 md:hidden"
        />
      )}
    </>
  );
}
