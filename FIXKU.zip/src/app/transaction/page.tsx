"use client";

import { useEffect, useState } from "react";
import Sidebar from "../components/sidebar";
import Header from "../components/headers";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencil, faTrash, faMagnifyingGlass, faFileDownload } from "@fortawesome/free-solid-svg-icons";
import { jsPDF } from 'jspdf';
import { autoTable } from 'jspdf-autotable';

type OrderItem = {
  idPesanan: number,
}

interface OrderResponse {
  success: boolean;
  data?: OrderItem[];
  message: string
}

export default function Home() {
  const [showModal, setShowModal] = useState(false);
  const [totalHarga, setTotalHarga] = useState<number>(0);
  const [bayar, setBayar] = useState<number>(0);
  const [idPesanan, setIdPesanan] = useState<{ idPesanan: number, total: number }[]>([]);
  const [currentPage, setCurrentPage] = useState(1)
  const [isEdit, setIsEdit] = useState(false);
  const [editingItem, setEditingItem] = useState<UsersDetails | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<string>(''); 
  const [editData, setEditData] = useState<UsersDetails | null>(null);
  const [orderDetails, setOrderDetails] = useState<UsersDetails[]>([])
  const itemsPerPage = 10
  const [kembalian, setKembalian] = useState<number>(0);
  const [selectedIdPesanan, setSelectedIdPesanan] = useState<number | null>(null);
  const [notification, setNotification] = useState<{
      type: 'success' | 'error',
      message: string
    } | null>(null)

  const showNotification = (type: 'success' | 'error', message: string) => {
      setNotification({ type, message })
      setTimeout(() => {
        setNotification(null)
      }, 3000)  
  }

  interface UsersDetails {
    success: boolean;
    IdTransaksi: number;
    idPesanan: number;
    total: number
    bayar: number
    status: string
  }

  interface TransaksiResponse {
    success: boolean
    IdTransaksi: number,
    idPesanan: number,
    total: number,
    bayar: number
  }

  const fetchorderDetails = async () => {
    try {
      const res = await fetch('/api/transaksi', {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          // "authorization": `Bearer ${localStorage.getItem('token')}`
        }
      })
      const data = await res.json()
      setOrderDetails(data)
    } catch (error) {
      console.error("Failed to fetch user data", error)
    }
  }

  useEffect(() => {
    fetchorderDetails()
  }, [])  

  const indexOfLastItem = currentPage * itemsPerPage
  const indexOfFirstItem = indexOfLastItem - itemsPerPage
  const currentItems = orderDetails.slice(indexOfFirstItem, indexOfLastItem)
  const totalPages = Math.ceil(orderDetails.length / itemsPerPage)
  const handleNext = () => {
    if (currentPage < totalPages) setCurrentPage(prev => prev + 1)
  }

  const handlePrev = () => {
    if (currentPage > 1) setCurrentPage(prev => prev - 1)
  }

  useEffect(() => {
    if (showModal) {
      fetch('/api/order')
        .then(res => res.json())
        .then(data => {
          const unpaid = data.data.filter((order: any) => order.status === 'UNPAID');
          setIdPesanan(unpaid);
          console.log('Unpaid orders:', unpaid);
        })
        .catch(error => {
          console.error('Error fetching orders:', error);
        });
    }
  }, [showModal]);  

  useEffect(() => {
    if (selectedIdPesanan) {
      const selectedOrder = idPesanan.find((order: any) => order.idPesanan === selectedIdPesanan);
      if (selectedOrder) {
        setTotalHarga(selectedOrder.total);
      }
    }
  }, [selectedIdPesanan, idPesanan]);

  useEffect(() => {
    if (bayar >= totalHarga) {
      setKembalian(bayar - totalHarga);
    } else {
      setKembalian(0);
    }
  }, [bayar, totalHarga]);

  const addTransaksi = async (totalHarga: number, selectedIdPesanan: number, bayar: number, kembalian: number) => {
    try {
      const response = await fetch('/api/transaksi', {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ idPesanan: selectedIdPesanan, total: totalHarga, bayar, kembalian})
      })
      const data: TransaksiResponse = await response.json();
      if (data.success) {
        showNotification('success', "Successfully add transaction");
        setShowModal(false);
        fetchorderDetails()
      }
    } catch (error: any) {
      console.log(error?.message || "Error internal server")
    }
  }

  const handleDelete = async (IdTransaksi: number) => {
    const response = await fetch("/api/transaksi", {
      method: "DELETE",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ IdTransaksi })
    })

    const data: TransaksiResponse = await response.json();
    if (data.success) {
      showNotification('success', "Successfully delete transaction");
      fetchorderDetails()
    }
    
  };
  
  const handleEdit = async (IdTransaksi: number) => {
    try {
      const response = await fetch('/api/transaksi', {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          IdTransaksi,
          total: totalHarga,
          bayar,
          kembalian,
          status: selectedStatus,
        }),
      });
  
      const data = await response.json();
      if (data.success) {
        showNotification('success', "Successfully update transaction");
        setShowModal(false);
        setIsEdit(false);
        setEditingItem(null);
        fetchorderDetails();
      }
    } catch (error: any) {
      console.log(error?.message || "Error internal server");
    }
  }

  const handleEditClick = (item: UsersDetails) => {
    setIsEdit(true);
    setEditingItem(item);
    setShowModal(true);
    setTotalHarga(item.total);
    setBayar(item.bayar);
    setSelectedStatus(item.status);
  };

  const generatePDFReport = (data: UsersDetails[]) => {
    const doc = new jsPDF();
    const currentDate = new Date().toLocaleDateString('id-ID');
    
    // Judul Laporan
    doc.setFontSize(18);
    doc.text(`Laporan Transaksi - ${currentDate}`, 14, 20);
    
    // Data untuk tabel
    const tableData = data.map(item => [
      item.IdTransaksi,
      item.idPesanan,
      `Rp ${item.total.toLocaleString('id-ID')}`,
      `Rp ${item.bayar.toLocaleString('id-ID')}`,
      `Rp ${(item.bayar - item.total).toLocaleString('id-ID')}`,
      item.status
    ]);
  
    // Kolom tabel
    const tableHeaders = [
      'ID Transaksi',
      'ID Pesanan',
      'Total',
      'Bayar',
      'Kembalian',
      'Status'
    ];
  
    // Generate tabel
    autoTable(doc, {
      head: [tableHeaders],
      body: tableData,
      startY: 30,
      theme: 'grid',
      styles: { fontSize: 9 },
      headStyles: { fillColor: [111, 130, 106] }
    });
  
    // Hitung summary
    const totalHarga = data.reduce((sum, item) => sum + item.total, 0);
    const totalBayar = data.reduce((sum, item) => sum + item.bayar, 0);
    const totalKembalian = data.reduce((sum, item) => sum + (item.bayar - item.total), 0);
    const jumlahTransaksi = data.length;
    const transaksiPaid = data.filter(item => item.status === 'PAID').length;
    const transaksiUnpaid = data.filter(item => item.status === 'UNPAID').length;
  
    // Position summary after the table
    const finalY = (doc as any).lastAutoTable.finalY || 30;
    
    // Summary Section
    doc.setFontSize(14);
    doc.text('Summary Transaksi', 14, finalY + 15);
    
    const summaryData = [
      [`Total Harga: Rp ${totalHarga.toLocaleString('id-ID')}`],
      [`Total Bayar: Rp ${totalBayar.toLocaleString('id-ID')}`],
      [`Total Kembalian: Rp ${totalKembalian.toLocaleString('id-ID')}`],
      [`Jumlah Transaksi: ${jumlahTransaksi}`],
      [`Transaksi Paid: ${transaksiPaid}`],
      [`Transaksi Unpaid: ${transaksiUnpaid}`]
    ];
  
    autoTable(doc, {
      body: summaryData,
      startY: finalY + 20,
      theme: 'plain',
      styles: { fontSize: 12 },
      columnStyles: { 0: { cellWidth: 180 } },
      tableLineColor: [0, 0, 0],
      tableLineWidth: 0.1
    });
  
    // Simpan PDF
    doc.save(`laporan-transaksi-${currentDate}.pdf`);
  };
  
  return (
    <div className="flex md:flex-row w-full bg-[#F0F1C5]/30 h-screen font-mono overflow-hidden select-none">
      <Sidebar />
      <div className="flex flex-col overflow-auto w-full h-full">
        <Header />
        <div className="relative">
          {notification && (
            <div className={`fixed top-0 right-0 mr-4 mt-4 z-[60] px-4 py-2 rounded-md shadow-lg text-[#6F826A] text-sm font-mono transition-all duration-300
              ${notification.type === 'success' ? 'bg-[#fff]' : 'bg-red-500'}`}>
              {notification.message}
            </div>
          )}
        </div>
        <div className="bg-[#6F826A] rounded-md shadow-sm ml-1 mr-2 mt-2 p-4">
          <p className="mb-3 mt-1 font-bold text-2xl text-white">Menu Transaksi</p>
          <div className="flex flex-col md:flex-row justify-between mb-3 gap-3">
            <div className="flex flex-col sm:flex-row gap-2">
              <button className="px-3 py-2 bg-white text-[#6F826A] rounded-md hover:bg-white/80 cursor-pointer duration-200 ease-in-out w-full sm:w-auto" onClick={() => setShowModal(true)}>Add Data</button>
              <button 
                className="px-3 py-2 bg-white text-[#6F826A] rounded-md hover:bg-white/80 cursor-pointer duration-200 ease-in-out w-full md:w-auto"
                onClick={() => generatePDFReport(orderDetails)}
              >
                Generate Report
              </button>
            </div>
            <div className="flex items-center gap-2 bg-[#6F826A] border border-gray-400 rounded-md px-3 py-2 w-full md:w-auto">
              <FontAwesomeIcon icon={faMagnifyingGlass} className="text-white h-4" />
              <input type="text" className="bg-transparent outline-none text-white placeholder-white text-sm w-full" placeholder="Search Data"/>
            </div>
          </div>

          <div className="w-full overflow-x-auto rounded-lg border border-gray-400">
            <table className="min-w-[600px] w-full text-left text-sm text-white table-auto border-collapse">
              <thead className="bg-[#5f725c]">
                <tr>
                  <th className="p-3 whitespace-nowrap rounded-tl-lg">ID TRANSAKSI</th>
                  <th className="p-3 whitespace-nowrap">ID PESANAN</th>
                  <th className="p-3 whitespace-nowrap">TOTAL</th>
                  <th className="p-3 whitespace-nowrap">BAYAR</th>
                  <th className="p-3 whitespace-nowrap">STATUS</th>
                  <th className="p-3 whitespace-nowrap rounded-tr-lg text-center">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="bg-[#7c8f77]">
                {currentItems.map((item, index) =>
                  <tr className="border-t border-gray-300" key={item.IdTransaksi}>
                    <td className="p-3 whitespace-nowrap">{item.IdTransaksi}</td>
                    <td className="p-3 whitespace-nowrap">{item.idPesanan}</td>
                    <td className="p-3 whitespace-nowrap">Rp. {item.total}</td>
                    <td className="p-3 whitespace-nowrap">Rp. {item.bayar}</td>
                    <td className="p-3 whitespace-nowrap">{item.status}</td>
                    <td className="p-3 whitespace-nowrap flex justify-center">
                      <button
                        className="w-10 h-full cursor-pointer"
                        id="editButton"
                        onClick={() => handleEditClick(item)}
                      >
                        <FontAwesomeIcon icon={faPencil} className="h-4" />
                      </button>

                      <button className="w-10 h-full cursor-pointer" onClick={() => handleDelete(item.IdTransaksi)} id="deleteButton">
                        <FontAwesomeIcon icon={faTrash} className="h-4" />
                      </button>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            <div className="flex w-full flex-col sm:flex-row justify-between items-center mt-2 gap-2">
              <button onClick={handlePrev} disabled={currentPage === 1} className="px-4 py-1 bg-white text-gray-700 rounded-md disabled:opacity-50 w-full sm:w-auto">Previous</button>
              <span className="text-sm text-white">
                Page {currentPage} of {totalPages}
              </span>
              <button onClick={handleNext} disabled={currentPage === totalPages} className="px-4 py-1 bg-gray-200 text-gray-700 rounded disabled:opacity-50 w-full sm:w-auto">Next</button>
            </div>
          </div>
        </div>

        {/* Transaction Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black/50 flex justify-center items-center z-50">
            <div className="bg-white rounded-lg px-4 py-6 sm:px-6 w-[90%] max-w-md">
            <h2 className="text-xl font-bold text-[#6F826A] mb-4">
                {isEdit ? 'Edit Data' : 'Add New Data'}
              </h2>
              <form>
              {!isEdit && (
                <>
                  <label className="block mb-1 text-black">ID Pesanan</label>
                  <select 
                    className="w-full mb-2 p-2 border rounded text-black bg-white"
                    value={selectedIdPesanan ?? ''}
                    onChange={(e) => setSelectedIdPesanan(Number(e.target.value))}
                  >
                    <option value="">-- Pilih Order ID --</option>
                    {idPesanan.map((pesanan, index) => (
                      <option key={pesanan.idPesanan} value={pesanan.idPesanan}>
                        {pesanan.idPesanan}
                      </option>
                    ))}
                  </select>
                </>
              )}

              {isEdit && (
                <>
                  <label className="block mb-1 text-black">Status</label>
                  <select 
                    className="w-full mb-2 p-2 border rounded text-black bg-white"
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value)}
                  >
                    <option value="">-- Pilih Status --</option>
                    <option value="PAID">PAID</option>
                    <option value="UNPAID">UNPAID</option>
                  </select>
                </>
              )}

              <label className="block mb-1 text-black">Total Bayar</label>
              <input
                type="number"
                value={totalHarga}
                onChange={(e) => setTotalHarga(Number(e.target.value))}
                className="w-full p-2 border rounded-md mb-2 text-black"
                disabled
              />

              <label className="block mb-1 text-black">Uang Bayar</label>
              <input
                type="number"
                value={bayar}
                onChange={(e) => setBayar(Number(e.target.value))}
                placeholder="Bayar"
                className="w-full p-2 border rounded-md mb-2 text-black"
              />

              <label className="block mb-1 text-black">Kembalian</label>
              <input
                type="number"
                value={kembalian}
                onChange={(e) => setKembalian(Number(e.target.value))}
                className="w-full p-2 border rounded-md mb-2 text-black"
                disabled
              />

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-black/50 duration-100 ease-in-out cursor-pointer"
                  onClick={() => {
                    setShowModal(false);
                    setIsEdit(false);
                    setEditingItem(null);
                    setSelectedIdPesanan(null);
                    setSelectedStatus('');
                    setBayar(0)
                    setKembalian(0)
                    setTotalHarga(0)
                  }}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (isEdit && editingItem) {
                      handleEdit(editingItem.IdTransaksi);
                    } else if (!isEdit && selectedIdPesanan !== null) {
                      addTransaksi(totalHarga, selectedIdPesanan, bayar, kembalian);
                    }
                  }}
                  className="px-4 py-2 bg-[#6F826A] text-white rounded-md cursor-pointer hover:bg-[#6F826A]/90 duration-100 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={
                    (!isEdit && (selectedIdPesanan === null || bayar <= 0)) || 
                    (isEdit && (bayar <= 0 || selectedStatus === ''))
                  }
                >
                  {isEdit ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}