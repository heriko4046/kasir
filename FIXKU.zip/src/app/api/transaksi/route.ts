import { db } from '../../../utils/db'
import jwt from 'jsonwebtoken'
import { RowDataPacket } from 'mysql2'
import { NextResponse } from 'next/server'

interface Transaksi extends RowDataPacket {
    id_pesanan: number;
    idTransaksi: number
}

export async function GET(request: Request) {
    try {
        const [rows] = await db.query(
            "SELECT IdTransaksi, idPesanan, total, bayar, status FROM transaksi ORDER BY IdTransaksi ASC LIMIT 50"
        );
    
        return NextResponse.json(rows);
    } catch (err: any) {
        return NextResponse.json({
            success: false,
            message: "error!",
            error: err?.message || "Internal server error"
        }, { status: 500 })
    }    
}

export async function DELETE(request: Request) {
    try {
        const { IdTransaksi } = await request.json()
        await db.query("DELETE FROM transaksi WHERE IdTransaksi = ?", [IdTransaksi])
        return NextResponse.json({
            success: true,
            message: `ID ${IdTransaksi} deleted.`
        }, { status: 200})
    } catch (err: any) {
        return NextResponse.json({
            success: false,
            message: "error!",
            error: err?.message || "Internal server error"
        })
    }
}

export async function PUT(request: Request) {
    try {
      const { IdTransaksi, total, bayar, kembalian, status } = await request.json();
  
      if (!IdTransaksi || !total || !bayar || !kembalian || !status) {
        return NextResponse.json({ message: 'Invalid data' }, { status: 400 });
      }
  
      await db.query(
        'UPDATE transaksi SET total = ?, bayar = ?, kembalian = ?, status = ? WHERE IdTransaksi = ?',
        [total, bayar, kembalian, status, IdTransaksi]
      );
  
      return NextResponse.json({ success: true, message: 'transaksi updated successfully' }, { status: 200 });
    } catch (error) {
      console.error('Error updating transaksi:', error);
      return NextResponse.json({ message: 'Internal server error' }, { status: 500 });
    }
  }

export async function POST(request: Request) {
    try {
        const { idPesanan, total, bayar, kembalian } = await request.json()
        if (!idPesanan || !total || !bayar || !kembalian) {
            return NextResponse.json({
                success: false,
                message: "All fields are required"
            }, { status: 400})
        }

        const [rows] = await db.query<Transaksi[]>('SELECT idPesanan FROM transaksi WHERE idPesanan = ?', [idPesanan])
        if (rows.length > 0) {
            return NextResponse.json({
                success: false,
                message: "transaction already exists."
            }, { status: 400})
        }

        await db.query('INSERT INTO transaksi (idPesanan, total, bayar, status, kembalian) VALUES (?, ?, ?, ?, ?)', [idPesanan, total, bayar, "PAID", kembalian])
        return NextResponse.json({
            success: true,
            message: "order created",
            data: {
                idPesanan, 
                total,
                bayar
            }
        }, { status: 201 })
    } catch (err: any) {
        return NextResponse.json({
            success: false,
            message: "error!",
            error: err?.message || "Internal server error"
        }, { status: 500 })
    }
}