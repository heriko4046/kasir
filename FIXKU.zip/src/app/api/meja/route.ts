import { db } from '../../../utils/db'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { RowDataPacket } from 'mysql2'
import { NextResponse } from 'next/server'

interface Menu extends RowDataPacket {
    idMeja: string
}

export async function DELETE(request: Request) {
    try {
        const { idMenu } = await request.json()
        await db.query("DELETE FROM menu WHERE idMenu = ?", [idMenu])
        return NextResponse.json({
            success: true,
            message: `User ${idMenu} deleted`
        }, { status: 200 })
    } catch (err: any) {
        return NextResponse.json({
            success: false,
            message: "error!",
            error: err?.message || "internal server error"
        })
    }
}

export async function GET(request: Request) {
    const [rows] = await db.query(
        "SELECT idMeja, idPelanggan, status FROM meja ORDER BY idMeja ASC LIMIT 50"
    );

    return NextResponse.json(rows);
}

export async function POST(request: Request) {
    try {
        const { status } = await request.json()
        if ( !status) {
            return NextResponse.json({
                success: false,
                message: "All fields are required."
            }, { status: 400 })
        }
        await db.query("INSERT INTO meja (status) values (?)", [status])
        return NextResponse.json({
            success: true,
            message: "table created",
            data: {
                status
            }
        }, { status: 201 })
    } catch (err: any) {
        return NextResponse.json({
            success: false,
            message: err?.message || "Internal server error"
        }, { status: 500 })
    }
}