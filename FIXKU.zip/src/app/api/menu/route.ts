import { db } from '../../../utils/db'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { RowDataPacket } from 'mysql2'
import { NextResponse } from 'next/server'

interface Menu extends RowDataPacket {
    namaMenu: string
}

export async function DELETE(request: Request) {
    try {
        const { idMenu } = await request.json()
        await db.query("DELETE FROM menu WHERE idMenu = ?", [idMenu])
        return NextResponse.json({
            success: true,
            message: `User ${idMenu} deleted`
        }, { status: 200 })
    } catch (err: any) {
        return NextResponse.json({
            success: false,
            message: "error!",
            error: err?.message || "internal server error"
        })
    }
}

export async function GET(request: Request) {
    const [rows] = await db.query(
        "SELECT idMenu, namaMenu, harga, stok FROM menu ORDER BY idMenu ASC LIMIT 50"
    );

    return NextResponse.json({
        success: true,
        data: rows
    });
}

export async function PUT(request: Request) {
    try {
      const { idMenu, namaMenu, harga } = await request.json();
  
      if (!idMenu || !namaMenu || harga === undefined) {
        return NextResponse.json({ message: 'Invalid data' }, { status: 400 });
      }
  
      await db.query(
        'UPDATE menu SET namaMenu = ?, harga = ? WHERE idMenu = ?',
        [namaMenu, harga, idMenu]
      );
  
      return NextResponse.json({ message: 'Menu updated successfully' }, { status: 200 });
    } catch (error) {
      console.error('Error updating menu:', error);
      return NextResponse.json({ message: 'Internal server error' }, { status: 500 });
    }
  }

export async function POST(request: Request) {
    try {
        const { namaMenu, harga } = await request.json()
        if (!namaMenu || !harga) {
            return NextResponse.json({
                success: false,
                message: "All fields are required."
            }, { status: 400 })
        }
        const [rows] = await db.query<Menu[]>("SELECT namaMenu FROM menu WHERE namaMenu = ?", [namaMenu])
        if (rows.length > 0) {
            return NextResponse.json({
                success: false,
                message: "menu exists"
            }, { status: 400})
        }
        await db.query("INSERT INTO menu (namaMenu, harga) values (?, ?)", [namaMenu, harga])
        return NextResponse.json({
            success: true,
            message: "menu created",
            data: {
                namaMenu,
                harga
            }
        }, { status: 201 })
    } catch (err: any) {
        return NextResponse.json({
            success: false,
            message: err?.message || "Internal server error"
        }, { status: 500 })
    }
}