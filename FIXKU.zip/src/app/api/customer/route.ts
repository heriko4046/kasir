import { db } from '../../../utils/db'
import { RowDataPacket } from 'mysql2'
import { NextResponse } from 'next/server'

interface Customer extends RowDataPacket {
    fullName: string
    gender: string
    noHandphone: number
    address: string
}

export async function GET(request: Request) {
    try {
        const [rows] = await db.query(
            "SELECT idPelanggan, fullName, gender, noHandphone, address FROM pelanggan ORDER BY idPelanggan ASC LIMIT 50"
        );
    
        return NextResponse.json({
            success: true,
            data: (rows)
        });
    } catch (err: any) {
        return NextResponse.json({
            success: false,
            message: "error!",
            error: err
        }, { status: 400 })
    }
}
export async function DELETE(request: Request) {
    try {
        const { idPelangan } = await request.json()
        await db.query("DELETE FROM pelanggan WHERE idPelanggan = ?", [idPelangan])
        return NextResponse.json({
            success: true,
            message: `User ${idPelangan} deleted`
        }, { status: 200 })
    } catch (err: any) {
        return NextResponse.json({
            success: false,
            message: "error!",
            error: err?.message || "internal server error"
        })
    }
}

export async function PUT(request: Request) {
    try {
      const { idPelanggan, fullName, gender, noHandphone, address } = await request.json();
  
      if (!idPelanggan || !fullName || gender === undefined || !noHandphone || !address) {
        return NextResponse.json({ message: 'Invalid data' }, { status: 400 });
      }
  
      await db.query(
        'UPDATE pelanggan SET fullName = ?, gender = ?, noHandphone = ?, address = ? WHERE idPelanggan = ?',
        [fullName, gender, noHandphone, address, idPelanggan]
      );
  
      return NextResponse.json({ message: 'customer updated successfully' }, { status: 200 });
    } catch (error) {
      console.error('Error updating customer:', error);
      return NextResponse.json({ message: 'Internal server error' }, { status: 500 });
    }
  }

export async function POST(request: Request) {
    try {
        const { fullName, gender, noHandphone, address } = await request.json()
        if (!fullName || !gender || !noHandphone || !address) {
            return NextResponse.json({
                success: false,
                message: "All fields are required"
            }, { status: 400 })
        }

        const [rows] = await db.query<Customer[]>("SELECT fullName FROM pelanggan where fullName = ? LIMIT 1", [fullName])
        if (rows.length > 0) {
            return NextResponse.json({
                success: false,
                message: "customer already exists"
            }, { status: 400 })
        }
        await db.query('INSERT INTO pelanggan (fullName, gender, noHandphone, address) VALUES (?, ?, ?, ?)', [fullName, gender, noHandphone, address])
        return NextResponse.json({
            success: true,
            message: "customer added",
            data: {
                fullName,
                gender,
                noHandphone,
                address
            }
        }, { status: 201 })
    } catch (err: any) {
        return NextResponse.json({
            success: false,
            message: "error!",
            error: err
        }, { status: 400 })
    }
}