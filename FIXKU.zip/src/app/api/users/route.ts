import { db } from '../../../utils/db'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { RowDataPacket } from 'mysql2'
import { NextResponse } from 'next/server'
import { Interface } from 'readline'
// import { verifyToken } from '../../utils/auth'

interface User extends RowDataPacket {
    user_name: string
  }

export async function DELETE(request: Request) {
    try {
        const { id } = await request.json()
        await db.query("DELETE FROM users WHERE id = ?", [id])
        return NextResponse.json({
            success: true,
            message: `User ${id} deleted`
        }, { status: 200 })
    } catch (err: any) {
        return NextResponse.json({
            success: false,
            message: "error!",
            error: err?.message || "internal server error"
        })
    }
}

export async function GET(request: Request) {
    const [rows] = await db.query(
        "SELECT id, user_name, user_fullname, role FROM users ORDER BY id ASC LIMIT 50"
    );

    return NextResponse.json(rows);
}

export async function PUT(request: Request) {
    try {
      const { id, user_name, user_password, user_fullname, role } = await request.json();
  
      if (!id || !user_name || user_password === undefined) {
        return NextResponse.json({ message: 'Invalid data' }, { status: 400 });
      }

      const bcryptPassword = await bcrypt.hash(user_password, 10)
      await db.query(
        'UPDATE users SET user_name = ?, user_password = ?, user_fullname = ?, role = ? WHERE id = ?',
        [user_name, bcryptPassword, user_fullname, role, id]
      );
  
      return NextResponse.json({ message: 'Menu updated successfully' }, { status: 200 });
    } catch (error) {
      console.error('Error updating menu:', error);
      return NextResponse.json({ message: 'Internal server error' }, { status: 500 });
    }
  }

export async function POST(request: Request) {
    try {
        const { user_name, full_name, user_password, role } = await request.json()
        if (!user_name || !full_name || !user_password || !role) {
            return NextResponse.json({
                success: false,
                message: "All fields are required."
            }, { status: 400 })
        }
        const bcryptPassword = await bcrypt.hash(user_password, 10)
        const [rows] = await db.query<User[]>('SELECT user_name FROM users WHERE user_name = ? LIMIT 1', [user_name])
        if (rows.length > 0) {
            return NextResponse.json({
                success: false,
                message: "user exists"
            }, { status: 400})
        }
        await db.query(
            'INSERT INTO users (user_name, user_fullname, user_password, role) VALUES (?, ?, ?, ?)',
            [user_name, full_name, bcryptPassword, role]
          )          
        return NextResponse.json({
            success: true,
            message: "user created",
            data: {
                  user_name,
                full_name,
                bcryptPassword,
                role
            }
        })
    } catch (error: any) {
        return NextResponse.json({
            success: false,
            message: error?.message || "Internal server error"
        }, { status: 500 })
    }
}