import { db } from '../../../utils/db';
import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  try {
    // Ambil data pesanan dari tabel pesanan
    const [pesananRows]: any[] = await db.query(`
      SELECT p.idPesanan, p.idMenu, p.idPelanggan, p.jumlah, p.idMenu, p.createdAt, p.idMeja, p.status, p.total
      FROM pesanan p
    `);

    // Format hasil data pesanan
    const result = pesananRows.map((pesanan: any) => {
      return {
        idPesanan: pesanan.idPesanan,
        namaMenu: pesanan.idMenu, // langsung pakai karena sudah ada nama
        idPelanggan: pesanan.idPelanggan,
        jumlah: pesanan.jumlah,
        idUser: pesanan.idUser,
        createdAt: pesanan.createdAt,
        idMeja: pesanan.idMeja,
        status: pesanan.status,
        total: pesanan.total
      };
    });

    return NextResponse.json({
      success: true,
      data: result
    });

  } catch (err: any) {
    console.error('Error saat mengambil data pesanan:', err);
    return NextResponse.json({
      success: false,
      message: err.message || "Internal server error",
    }, { status: 500 });
  }
}




export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { idPelanggan, idUser, idMeja, idMenu, jumlah, total } = body;

    // Validasi input
    if (
      typeof idPelanggan !== 'number' ||
      typeof idUser !== 'number' ||
      typeof idMeja !== 'number' ||
      typeof idMenu !== 'string' ||
      typeof jumlah !== 'string' ||
      idMenu.trim() === '' ||
      jumlah.trim() === ''
    ) {
      return NextResponse.json({
        success: false,
        message: "idPelanggan, idUser, idMeja, idMenu, dan jumlah wajib diisi",
      }, { status: 400 });
    }

    // Parsing idMenu
    const idMenuList = idMenu.split(',').map(id => parseInt(id.trim())).filter(id => !isNaN(id));
    const jumlahList = jumlah.split(',').map(j => parseInt(j.trim())).filter(j => !isNaN(j));

    if (idMenuList.length === 0 || jumlahList.length === 0 || idMenuList.length !== jumlahList.length) {
      return NextResponse.json({
        success: false,
        message: "idMenu atau jumlah tidak valid",
      }, { status: 400 });
    }

    // Ambil nama menu
    const [rows]: any[] = await db.query(
      `SELECT idMenu, namaMenu FROM menu WHERE idMenu IN (${idMenuList.map(() => '?').join(',')})`,
      idMenuList
    );

    // Map idMenu ke namaMenu
    const menuMap: Record<number, string> = {};
    for (const row of rows) {
      menuMap[row.idMenu] = row.namaMenu;
    }

    // Gabungkan jadi string: Nama (jumlah) (idMenu)
    const menuString = idMenuList.map((id, idx) => {
      const nama = menuMap[id] || 'Menu Tidak Diketahui';
      const jml = jumlahList[idx] || 0;
      return `${nama} (x${jml})`;
    }).join(', ');


    // Mulai transaksi untuk memasukkan pesanan dan memperbarui meja
    await db.query('START TRANSACTION');

    // Simpan ke tabel pesanan
    await db.query(
      'INSERT INTO pesanan (idMenu, idPelanggan, jumlah, idUser, createdAt, idMeja, status, total) VALUES (?, ?, ?, ?, NOW(), ?, ?, ?)',
      [menuString, idPelanggan, jumlah, idUser, idMeja, 'UNPAID', total]
    );

    // Perbarui status meja menjadi 'notavailable' dan set idPelanggan pada meja
    await db.query(
      'UPDATE meja SET status = "taken", idPelanggan = ? WHERE idMeja = ?',
      [idPelanggan, idMeja]
    );

    // Commit transaksi jika tidak ada error
    await db.query('COMMIT');

    return NextResponse.json({
      success: true,
      message: "Pesanan berhasil dimasukkan dan status meja diperbarui.",
    }, { status: 201 });

  } catch (err: any) {
    console.error("Error kirim pesanan:", err);

    // Rollback jika terjadi error
    await db.query('ROLLBACK');

    return NextResponse.json({
      success: false,
      message: err.message || "Internal server error",
    }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
      const { idPesanan } = await request.json()
      await db.query("DELETE FROM pesanan WHERE idPesanan = ?", [idPesanan])
      return NextResponse.json({
          success: true,
          message: `order ${idPesanan} deleted`
      }, { status: 200 })
  } catch (err: any) {
      return NextResponse.json({
          success: false,
          message: "error!",
          error: err?.message || "internal server error"
      })
  }
}

