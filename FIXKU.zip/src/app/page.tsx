"use client"

import { useState, useEffect } from 'react';
import Sidebar from "./components/sidebar";
import Header from "./components/headers";

const Dashboard = () => {
  const [unpaidCount, setUnpaidCount] = useState(0);
  const [paidCount, setPaidCount] = useState(0);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error',
    message: string
  } | null>(null)

  const showNotification = (type: 'success' | 'error', message: string) => {
      setNotification({ type, message })
      setTimeout(() => {
        setNotification(null)
      }, 3000)  
  }
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch orders
        const orderRes = await fetch("/api/order");
        const orderData = await orderRes.json();
        
        // Count unpaid orders
        const unpaidOrders = orderData.data.filter((order: any) => order.status === "UNPAID");
        setUnpaidCount(unpaidOrders.length);

        // Fetch transactions
        const transRes = await fetch("/api/transaksi");
        const transData = await transRes.json();

        // Count paid transactions
        const paidTransactions = transData.filter((trans: any) => trans.status === "PAID");
        setPaidCount(paidTransactions.length);
        
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="flex md:flex-row w-full bg-[#F0F1C5]/30 h-screen font-mono overflow-hidden select-none">
      <Sidebar />
      <div className="flex flex-col overflow-auto w-full h-full">
        <Header />
        <div className="relative">
          {notification && (
            <div className={`fixed top-0 right-0 mr-4 mt-4 z-[60] px-4 py-2 rounded-md shadow-lg text-[#6F826A] text-sm font-mono transition-all duration-300
              ${notification.type === 'success' ? 'bg-[#fff]' : 'bg-red-500'}`}>
              {notification.message}
            </div>
          )}
        </div>

        {/* Dashboard content */}
        <div className="flex flex-col md:flex-row gap-4 px-4 py-6">
          
          {/* Unpaid Orders Card */}
          <div className="flex-1 bg-white rounded-lg shadow-md p-4">
            <p className="font-bold text-xl text-[#6F826A] mb-4">Unpaid Orders</p>
            <div className="bg-[#F0F1C5] p-4 rounded-md shadow-md">
              <p className="text-2xl font-semibold text-[#6F826A]">{unpaidCount} Orders</p>
            </div>
          </div>

          {/* Paid Transactions Card */}
          <div className="flex-1 bg-white rounded-lg shadow-md p-4">
            <p className="font-bold text-xl text-[#6F826A] mb-4">Paid Transactions</p>
            <div className="bg-[#F0F1C5] p-4 rounded-md shadow-md">
              <p className="text-2xl font-semibold text-[#6F826A]">{paidCount} Transactions</p>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Dashboard;
