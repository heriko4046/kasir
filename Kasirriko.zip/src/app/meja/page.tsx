"use client";

import { useEffect, useState } from "react";
import Sidebar from "../components/sidebar";
import Header from "../components/headers";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencil, faTrash, faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";

export default function Home() {
  const [showModal, setShowModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1)
  const [status, setStatus] = useState('DEFAULT');
  const [menuDetails, setMenuDetails] = useState<UsersDetails[]>([])
  const itemsPerPage = 10
  const [notification, setNotification] = useState<{
      type: 'success' | 'error',
      message: string
    } | null>(null)

  const showNotification = (type: 'success' | 'error', message: string) => {
      setNotification({ type, message })
      setTimeout(() => {
        setNotification(null)
      }, 3000)  
  }

  interface UsersDetails {
    success: boolean;
    idMeja: number;
    status: string;
    idPelanggan: string;
  }

  interface MenuResponse {
    success: boolean
  }

  const fetchmenuDetails = async () => {
    try {
      const res = await fetch('/api/meja', {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          // "authorization": `Bearer ${localStorage.getItem('token')}`
        }
      })
      const data = await res.json()
      setMenuDetails(data)
    } catch (error) {
      console.error("Failed to fetch user data", error)
    }
  }

  useEffect(() => {
    fetchmenuDetails()
  }, [])

  const indexOfLastItem = currentPage * itemsPerPage
  const indexOfFirstItem = indexOfLastItem - itemsPerPage
  const currentItems = menuDetails.slice(indexOfFirstItem, indexOfLastItem)
  const totalPages = Math.ceil(menuDetails.length / itemsPerPage)
  const handleNext = () => {
    if (currentPage < totalPages) setCurrentPage(prev => prev + 1)
  }

  const handlePrev = () => {
    if (currentPage > 1) setCurrentPage(prev => prev - 1)
  }

  const addMeja = async (status: string) => {
    try {
      const response = await fetch('/api/meja', {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ status })
      })
      const data: MenuResponse = await response.json();
      if (data.success) {
        showNotification('success', "Successfully add menu");
        setShowModal(false);
        fetchmenuDetails()
      }
    } catch (error: any) {
      console.log(error?.message || "Error internal server")
    }
  }

  const handleDelete = async (idMenu: number) => {
    const response = await fetch("/api/menu", {
      method: "DELETE",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ idMenu })
    })

    const data: MenuResponse = await response.json();
    if (data.success) {
      showNotification('success', "Successfully delete transaction");
      fetchmenuDetails()
    }
  };  

  return (
    <div className="flex md:flex-row w-full bg-[#F0F1C5]/30 h-screen font-mono overflow-hidden select-none">
      <Sidebar />
      <div className="flex flex-col overflow-auto w-full h-full">
        <Header />
        <div className="relative">
          {notification && (
            <div className={`fixed top-0 right-0 mr-4 mt-4 z-[60] px-4 py-2 rounded-md shadow-lg text-[#6F826A] text-sm font-mono transition-all duration-300
              ${notification.type === 'success' ? 'bg-[#fff]' : 'bg-red-500'}`}>
              {notification.message}
            </div>
          )}
        </div>
        <div className="bg-[#6F826A] rounded-md shadow-sm ml-1 mr-2 mt-2 p-4">
          <p className="mb-3 mt-1 font-bold text-2xl text-white">Menu Food</p>
          <div className="flex flex-col md:flex-row justify-between mb-3 gap-3">
            <button className="px-3 py-2 bg-white text-[#6F826A] rounded-md hover:bg-white/80 cursor-pointer duration-200 ease-in-out w-full md:w-auto" onClick={() => setShowModal(true)} >Add Data</button>
            <div className="flex items-center gap-2 bg-[#6F826A] border border-gray-400 rounded-md px-3 py-2 w-full md:w-auto">
              <FontAwesomeIcon icon={faMagnifyingGlass} className="text-white h-4" />
              <input type="text" className="bg-transparent outline-none text-white placeholder-white text-sm w-full" placeholder="Search Data"/>
            </div>
          </div>

          <div className="w-full overflow-x-auto rounded-lg border border-gray-400">
            <table className="min-w-[600px] w-full text-left text-sm text-white table-auto border-collapse">
              <thead className="bg-[#5f725c]">
                <tr>
                  <th className="p-3 whitespace-nowrap rounded-tl-lg">NO MEJA</th>
                  <th className="p-3 whitespace-nowrap rounded-tl-lg">ID PELANGGAN</th>
                  <th className="p-3 whitespace-nowrap">STATUS</th>
                  <th className="p-3 whitespace-nowrap rounded-tr-lg text-center">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="bg-[#7c8f77]">
                {currentItems.map((item, index) =>
                  <tr className="border-t border-gray-300" key={item.idMeja}>
                    <td className="p-3 whitespace-nowrap">{item.idMeja}</td>
                    <td className="p-3 whitespace-nowrap">{item.idPelanggan}</td>
                    <td className="p-3 whitespace-nowrap">{item.status}</td>
                    <td className="p-3 whitespace-nowrap flex justify-center">
                      <button className="w-10 h-full cursor-pointer" onClick={() => handleDelete(item.idMeja)} id="deleteButton">
                        <FontAwesomeIcon icon={faTrash} className="h-4" />
                      </button>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            <div className="flex w-full flex-col sm:flex-row justify-between items-center mt-2 gap-2">
              <button onClick={handlePrev} disabled={currentPage === 1} className="px-4 py-1 bg-white text-gray-700 rounded-md disabled:opacity-50 w-full sm:w-auto">Previous</button>
              <span className="text-sm text-white">
                Page {currentPage} of {totalPages}
              </span>
              <button onClick={handleNext} disabled={currentPage === totalPages} className="px-4 py-1 bg-gray-200 text-gray-700 rounded disabled:opacity-50 w-full sm:w-auto">Next</button>
            </div>
          </div>
        </div>

        {showModal && (
          <div className="fixed inset-0 bg-black/50 flex justify-center items-center z-50">
            <div className="bg-white rounded-lg px-4 py-6 sm:px-6 w-[90%] max-w-md">
              <h2 className="text-xl font-bold text-[#6F826A] mb-4">Add New Data</h2>
              <form className="">
                <select name="" id="" value={status} onChange={(e) => setStatus(e.target.value)} className="w-full p-2 border rounded-md mb-3 text-[#6F826A]">
                  <option value="DEFAULT" className="" disabled hidden>Status</option>
                  <option value="available" className="text-[#6F826A]">Available</option>
                  <option value="taken" className="text-[#6F826A]">Taken</option>
                </select>
                <div className="flex justify-end gap-2">
                  <button type="button" className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-black/50 duration-100 ease-in-out cursor-pointer" onClick={() => setShowModal(false)}>Cancel</button>
                  <button type="button" onClick={() => addMeja(status)} className="px-4 py-2 bg-[#6F826A] text-white rounded-md cursor-pointer hover:bg-[#6F826A]/90 duration-100 ease-in-out">Save</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}