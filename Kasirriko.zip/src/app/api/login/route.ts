import { db } from '../../../utils/db'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { RowDataPacket } from 'mysql2'
import { NextResponse } from 'next/server'
// import { verifyToken } from '../../utils/auth'

type User = {
    id: number
    user_name: string
    user_password: string
} & RowDataPacket

const JWT_SECRET = process.env.JWT_SECRET || 'kontolbapakkau'

export async function GET(request: Request) {
    return NextResponse.json({
        message: "success"
    })
}

export async function POST(request: Request) { 
    try {
        const { email, password } = await request.json()

        // Fetch user data including role
        const [rows] = await db.query<User[]>("SELECT id, user_name, user_password, role FROM users WHERE user_name = ?", [email]);
        const user = rows[0];

        if (!user) {
            return NextResponse.json({
                success: false,
                message: "User not registered"
            }, { status: 401 });
        }

        // Compare passwords
        const passwordMatch = await bcrypt.compare(password, user.user_password);
        if (!passwordMatch) {
            return NextResponse.json({
                success: false,
                message: "Wrong email/password"
            });
        }

        // Generate JWT token including role
        const tokenJwt = jwt.sign({
            id: user.id,
            email: user.user_name,
            role: user.role,  // Add role to the JWT payload
        }, JWT_SECRET, { expiresIn: "3d" });

        return NextResponse.json({
            success: true,
            message: "Login successful",
            data: {
                email: user.user_name,
                tokenJwt,
                role: user.role,  // Include role in the response
            }
        });

    } catch (error: any) {
        return NextResponse.json({
            success: false,
            message: error.message || "An error occurred"
        });
    }
}
