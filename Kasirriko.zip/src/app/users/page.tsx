"use client";

import { useEffect, useState } from "react";
import Sidebar from "../components/sidebar";
import Header from "../components/headers";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencil, faTrash, faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";

export default function Home() {
  const [showModal, setShowModal] = useState(false);
  const [user_name, setUserName] = useState("");
  const [full_name, setFullName] = useState("");
  const [isEdit, setIsEdit] = useState(false);
  const [editData, setEditData] = useState<any>(null);
  const [user_password, setUserPassword] = useState("");
  const [role, setRole] = useState('DEFAULT')
  const [currentPage, setCurrentPage] = useState(1)
  const [userDetails, setUserDetails] = useState<UsersDetails[]>([])
  const itemsPerPage = 10
  const [notification, setNotification] = useState<{
      type: 'success' | 'error',
      message: string
    } | null>(null)

  const showNotification = (type: 'success' | 'error', message: string) => {
      setNotification({ type, message })
      setTimeout(() => {
        setNotification(null)
      }, 3000)  
  }

  interface LoginResponse {
    success: boolean;
    user_name: string;
    full_name: string;
    role: string
  }

  interface UsersDetails {
    id: number;
    user_name: string
    user_fullname: string
    role: string
  }

  const fetchUserDetails = async () => {
    try {
      const res = await fetch('/api/users', {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          // "authorization": `Bearer ${localStorage.getItem('token')}`
        }
      })
      const data = await res.json()
      setUserDetails(data)
    } catch (error) {
      console.error("Failed to fetch user data", error)
    }
  }

  useEffect(() => {
    fetchUserDetails()
  }, [])  

  const indexOfLastItem = currentPage * itemsPerPage
  const indexOfFirstItem = indexOfLastItem - itemsPerPage
  const currentItems = userDetails.slice(indexOfFirstItem, indexOfLastItem)
  const totalPages = Math.ceil(userDetails.length / itemsPerPage)
  const handleNext = () => {
    if (currentPage < totalPages) setCurrentPage(prev => prev + 1)
  }

  const handlePrev = () => {
    if (currentPage > 1) setCurrentPage(prev => prev - 1)
  }

  const addUser = async (user_name: string, user_password: string, full_name: string, role: string) => {
    try {
      const response = await fetch('/api/users', {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ user_name, user_password, full_name, role })
      })
      const data: LoginResponse = await response.json();
      if (data.success) {
        showNotification('success', "Successfully add user");
        setShowModal(false);
        fetchUserDetails()
      }
    } catch (error: any) {
      console.log(error?.message || "Error internal server")
    }
  }

  const handleDelete = async (id: number) => {
    const response = await fetch("/api/users", {
      method: "DELETE",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ id })
    })

    const data: LoginResponse = await response.json();
    console.log(data)
    if (data.success) {
      showNotification('success', "Successfully delete transaction");
      fetchUserDetails()
    }
  };  

  const handleEdit = (item: any) => {
    setIsEdit(true);         // Masuk mode edit
    setEditData(item);       // Set data yang mau diedit
    setUserName(item.user_name);
    setFullName(item.user_fullname);
    setRole(item.role);
    setUserPassword('');     // Kosongin password, biar harus diisi ulang kalau mau update
    setShowModal(true);      // Tampilkan modal
  };

  const updateUser = (id: number, user_name: string, user_password: string, user_fullname: string, role: string) => {
    if (!user_name || !user_fullname || !role) {
      setNotification({ type: 'error', message: 'Please fill all fields' });
      return;
    }
    
    // Simpan ke API
    fetch(`/api/users/`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, user_name, user_password, user_fullname, role })
    })
      .then(res => res.json())
      .then(data => {
        setNotification({ type: 'success', message: 'Data updated successfully!' });
        setShowModal(false);
        setIsEdit(false);
        setEditData(null);
        fetchUserDetails(); 
      })
      .catch(error => {
        setNotification({ type: 'error', message: 'Error updating user' });
        console.error('Update error:', error);
      });
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setIsEdit(false);
    setEditData(null);
    setUserName('');
    setFullName('');
    setUserPassword('');
    setRole('DEFAULT');
  };
  
  

  return (
    <div className="flex md:flex-row w-full bg-[#F0F1C5]/30 h-screen font-mono overflow-hidden select-none">
      <Sidebar />
      <div className="flex flex-col overflow-auto w-full h-full">
        <Header />
        <div className="relative">
          {notification && (
            <div className={`fixed top-0 right-0 mr-4 mt-4 z-[60] px-4 py-2 rounded-md shadow-lg text-[#6F826A] text-sm font-mono transition-all duration-300
              ${notification.type === 'success' ? 'bg-[#fff]' : 'bg-red-500'}`}>
              {notification.message}
            </div>
          )}
        </div>
        <div className="bg-[#6F826A] rounded-md shadow-sm ml-1 mr-2 mt-2 p-4">
          <p className="mb-3 mt-1 font-bold text-2xl text-white">Menu Users Data</p>
          <div className="flex flex-col md:flex-row justify-between mb-3 gap-3">
            <button className="px-3 py-2 bg-white text-[#6F826A] rounded-md hover:bg-white/80 cursor-pointer duration-200 ease-in-out w-full md:w-auto" onClick={() => setShowModal(true)} >Add Data</button>
            <div className="flex items-center gap-2 bg-[#6F826A] border border-gray-400 rounded-md px-3 py-2 w-full md:w-auto">
              <FontAwesomeIcon icon={faMagnifyingGlass} className="text-white h-4" />
              <input type="text" className="bg-transparent outline-none text-white placeholder-white text-sm w-full" placeholder="Search Data"/>
            </div>
          </div>

          <div className="w-full overflow-x-auto rounded-lg border border-gray-400">
            <table className="min-w-[600px] w-full text-left text-sm text-white table-auto border-collapse">
              <thead className="bg-[#5f725c]">
                <tr>
                  <th className="p-3 whitespace-nowrap rounded-tl-lg">ID</th>
                  <th className="p-3 whitespace-nowrap">USERNAME</th>
                  <th className="p-3 whitespace-nowrap">FULLNAME</th>
                  <th className="p-3 whitespace-nowrap">ROLE</th>
                  <th className="p-3 whitespace-nowrap rounded-tr-lg text-center">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="bg-[#7c8f77]">
                {currentItems.map((item, index) =>
                  <tr className="border-t border-gray-300" key={item.id}>
                    <td className="p-3 whitespace-nowrap">{item.id}</td>
                    <td className="p-3 whitespace-nowrap">{item.user_name}</td>
                    <td className="p-3 whitespace-nowrap">{item.user_fullname}</td>
                    <td className="p-3 whitespace-nowrap">{item.role}</td>
                    <td className="p-3 whitespace-nowrap flex justify-center">
                      <button className="w-10 h-full cursor-pointer" onClick={() => handleEdit(item)} id="editButton">
                        <FontAwesomeIcon icon={faPencil} className="h-4" />
                      </button>
                      <button className="w-10 h-full cursor-pointer" onClick={() => handleDelete(item.id)} id="deleteButton">
                        <FontAwesomeIcon icon={faTrash} className="h-4" />
                      </button>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            <div className="flex w-full flex-col sm:flex-row justify-between items-center mt-2 gap-2">
              <button onClick={handlePrev} disabled={currentPage === 1} className="px-4 py-1 bg-white text-gray-700 rounded-md disabled:opacity-50 w-full sm:w-auto">Previous</button>
              <span className="text-sm text-white">
                Page {currentPage} of {totalPages}
              </span>
              <button onClick={handleNext} disabled={currentPage === totalPages} className="px-4 py-1 bg-gray-200 text-gray-700 rounded disabled:opacity-50 w-full sm:w-auto">Next</button>
            </div>
          </div>
        </div>

        {showModal && (
          <div className="fixed inset-0 bg-black/50 flex justify-center items-center z-50">
            <div className="bg-white rounded-lg px-4 py-6 sm:px-6 w-[90%] max-w-md">
            <h2 className="text-xl font-bold text-[#6F826A] mb-4">
              {isEdit ? 'Edit Data' : 'Add New Data'}
            </h2>
              <form className="">
                <input type="text" value={user_name} onChange={(e) => setUserName(e.target.value)} placeholder="Username" className="w-full p-2 border rounded-md mb-3 text-[#6F826A]" />
                <input type="text" value={full_name} onChange={(e) => setFullName(e.target.value)} placeholder="Full Name" className="w-full p-2 border rounded-md mb-3 text-[#6F826A]" />
                <input type="password" value={user_password} onChange={(e) => setUserPassword(e.target.value)} placeholder="Password" className="w-full p-2 border rounded-md mb-3 text-[#6F826A]" />
                <select name="" id="" value={role} onChange={(e) => setRole(e.target.value)} className="w-full p-2 border rounded-md mb-3 text-[#6F826A]">
                  <option value="DEFAULT" className="" disabled hidden>Role</option>
                  <option value="admin" className="text-[#6F826A]">Admin</option>
                  <option value="waiter" className="text-[#6F826A]">Waiter</option>
                  <option value="kasir" className="text-[#6F826A]">Kasir</option>
                  <option value="owner" className="text-[#6F826A]">Owner</option>
                </select>
                <div className="flex justify-end gap-2">
                  <button type="button" className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-black/50 duration-100 ease-in-out cursor-pointer" onClick={handleCloseModal}>Cancel</button>
                  <button
                    type="button"
                    onClick={() => {
                      if (isEdit && editData) {
                        updateUser(editData.id, user_name, user_password, full_name, role);
                      } else {
                        addUser(user_name, user_password, full_name, role);
                      }
                    }}
                    className="px-4 py-2 bg-[#6F826A] text-white rounded-md cursor-pointer hover:bg-[#6F826A]/90 duration-100 ease-in-out"
                  >
                    {isEdit ? 'Update' : 'Save'}
                  </button>

                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}