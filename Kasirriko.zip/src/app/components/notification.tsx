import { useState } from "react";

const [role, setRole] = useState('DEFAULT')
const [notification, setNotification] = useState<{
  type: 'success' | 'error',
  message: string
} | null>(null)

export const showNotification = (type: 'success' | 'error', message: string) => {
  setNotification({ type, message })
  setTimeout(() => {
    setNotification(null)
  }, 3000)
}
