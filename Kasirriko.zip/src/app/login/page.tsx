"use client"

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function Home() {
  const [emailAddress, setEmailAddress] = useState("")
  const [password, setPassword] = useState("")
  const router = useRouter()

  interface LoginResponse {
    success: boolean,
    tokenJwt?: string,
    message: string,
    emailAddress: string
    data?: any
  }

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    submitLogin(emailAddress, password); // kamu tetap pakai parameter biasa
  };

  const submitLogin = async (emailAddress: string, password: string) => {
    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: {"Content-Type": "application/json", "User-Agent": "ayamLoncat 3.10"},
        body: JSON.stringify({
          email: emailAddress,
          password
        })
      });

      const data: LoginResponse = await response.json();
      if (data.success) {
        console.log("s")
        localStorage.setItem("token", data.data.tokenJwt);
        localStorage.setItem("email", data.data.email);
        localStorage.setItem("role", data.data.role);
        console.log("berhasil masuk")
        router.push("/dashboard")
      }
    } catch (error) {
      console.log(error)
    }
  }
  
  return (
    <div className="flex flex-col md:flex-row w-full bg-[#F0F1C5] h-screen items-center justify-center font-mono overflow-hidden select-none">
      <div className="w-full max-w-md mx-auto p-8 bg-[#fff] shadow-xl rounded-2xl">
        <h2 className="font-bold text-black text-center mb-5">LOG IN TO YOUR ACCOUNT</h2>
          <form action="" onSubmit={handleSubmit} className="flex flex-col text-black">
            <label htmlFor="" className="mb-1">Email Address</label>
            <input type="text" value={emailAddress} onChange={(e) => setEmailAddress(e.target.value)} className="focus:outline-[#6F826A] mb-2 p-2 border border-gray-400 rounded-sm" placeholder="Enter your email" required/>
            <label htmlFor="" className="mb-1">Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="mb-4 p-2 border border-gray-400 rounded-sm" placeholder="Enter your password" required/>
            <button type="submit" className="w-full rounded-sm text-white bg-[#6F826A] hover:bg-[#6F826A]/90 duration-200 cursor-pointer p-2">Log in</button>
          </form>
      </div>
    </div>
  );
}
