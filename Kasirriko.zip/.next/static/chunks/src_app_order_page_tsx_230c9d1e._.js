(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_a8b3cb5a._.js",
  "static/chunks/b8af9_@fortawesome_free-solid-svg-icons_index_mjs_f5e428c4._.js",
  "static/chunks/node_modules__pnpm_e7f402b1._.js"
],
    source: "dynamic"
});
